# Energy-Life-UI-Design-Android
Energy Life Even App UI design made with Android Studio (XML)

## Getting Started

Just Download it and open with Android Studio that's it.

### Prerequisites

Need Android Studio

![android_event_app_ui_mockup_small](https://user-images.githubusercontent.com/55942632/66915535-dc833f80-f036-11e9-8fd9-354dac31c996.png)

## Built With

* [Maven](https://maven.apache.org/) - Dependency Management
* [Flaticon](https://flaticon.com) - Used to get amazing icons

## Contributing

Please read [CONTRIBUTING.md](https://gist.github.com/PurpleBooth/b24679402957c63ec426) for details on our code of conduct, and the process for submitting pull requests to us.

## Authors

* **Sanskar Tiwari** - *Initial work* - [Theindianappguy](https://www.facebook.com/Theindianappguy-111238193612220/)

See also the list of [contributors](https://github.com/theindianappguy/SampleProfileUi/contributors) who participated in this project.

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments

* [Join Our Facebook Group](https://www.facebook.com/groups/519517995532897/) - I share a lot of value in it
* [Theindianappguy Chatbot ](https://m.me/111238193612220?ref=w7628342) - Never miss any updates of the codes i share, Make sure you are already logged in to facebook. 

